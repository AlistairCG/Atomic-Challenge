#include "Utilities.h"

Utilities::Utilities(): field_width(1)
{}

const std::string Utilities::nextToken(const std::string &, size_t &, bool &)
{
	//Set start of check
	string check = str;


	//===Get string start pos and substr. Substr to delim if available===//
	check = check.substr(next_pos);



	if (check.find(delimiter) == string::npos) {
		check = check.substr(0, check.find_first_of("\r\n")); //Get everything to eof
	}
	else {

		size_t lk = check.find_first_not_of(' ');
		size_t tk = check.find_first_not_of(delimiter);
		size_t ck = check.find_first_of(delimiter);

		//===Prevent Exception===//

		//Check for delim before token, and if the delim is the first found char. Throw in both cases.
		//Aside: This if statement gave me hell, trying to get a string literal to play nice with a string object on matrix stinks.
		if (ck < tk || lk == ck) {
			string tmp = " <== Delimiter Found before tokens!";

			ostringstream err;
			err << check << tmp;
			string cerr = err.str(); //Convert oss to str. 

			throw cerr;
			more = false;//
			return ""; //Escape and dont print record
		}//===========//
		else {
			check = check.substr(0, check.find(delimiter));//Eat till found delim
		}
	}


	//===========Ln 37 <-> Ln 72======//


	//===Update class attributes(not with trimmed changes as next iteration wont have them!)=====//
	next_pos += check.size() + 1;
	if (next_pos >= str.size()) {
		more = false;
	}
	//=================//

	//===========Catch an empty string after next pos(notice that no returns inside if, as this is checking  a 'future' string)========//
	string tmp;
	if (more)tmp = str.substr(next_pos); //Exception safety, prevent out of bounds where end of string//
	if (tmp.find_first_not_of(' ') == string::npos) {
		more = false;
	}
	//=========================================//

	//========LTrim + RTrim w/Exception Safety(notice using check, not string tmp/ current vs future string inspect).==============//
	if (check.find_first_not_of(' ') == string::npos) {
		more = false;
		return ""; //

	}
	check = check.substr(check.find_first_not_of(' '));
	check = check.substr(0, check.find_last_not_of(' ') + 1);
	//===========================//
	//Update fields if needed//
	if (field_width < check.size()) {
		field_width = check.size();
	}
	//========================//


	return check;

}
